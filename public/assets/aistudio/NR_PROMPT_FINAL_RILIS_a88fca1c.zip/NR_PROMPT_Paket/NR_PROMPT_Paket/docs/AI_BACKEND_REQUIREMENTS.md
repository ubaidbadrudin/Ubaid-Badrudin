# Persyaratan integrasi AI backend

Source saat ini merupakan frontend statis/PWA dan aplikasi Android WebView. Untuk menjadikan tombol generator terhubung ke model AI secara nyata, diperlukan keputusan dan konfigurasi berikut:

1. Penyedia AI dan model yang akan digunakan.
2. Backend HTTPS (misalnya Node.js/Express, serverless function, atau layanan backend lain).
3. API key yang disimpan sebagai secret di sisi server, bukan di frontend.
4. Endpoint aplikasi, misalnya `POST /api/generate`, dengan validasi panjang input dan format output.
5. Autentikasi/otorisasi bila penggunaan dibatasi per akun.
6. Rate limiting, kuota, pencatatan biaya, dan penanganan error.
7. Database hanya jika perlu menyimpan pengguna, prompt, atau riwayat lintas perangkat.

Contoh kontrak endpoint (ilustrasi):

```http
POST /api/generate
Content-Type: application/json
Authorization: Bearer <session-token>

{
  "task": "business-promo",
  "prompt": "Buat promosi nasi box untuk pelanggan kantor",
  "tone": "persuasive"
}
```

Backend mengembalikan JSON berisi hasil yang telah divalidasi. API key provider AI tidak pernah dikirim ke browser atau APK.
