# Checklist final rilis NR_PROMPT

## Website / PWA
- [ ] Pilih domain dan hosting HTTPS.
- [ ] Unggah isi folder `website` ke root hosting.
- [ ] Buka URL HTTPS di Android dan desktop.
- [ ] Uji instalasi PWA dari Chrome Android.
- [ ] Uji mode offline setelah kunjungan pertama.
- [ ] Uji navigasi, generator, copy, dan tampilan layar kecil.
- [ ] Tambahkan email/kontak pengelola serta kebijakan privasi final.

## Android APK
- [ ] Buka `android-app` di Android Studio.
- [ ] Sinkronkan Gradle dan pasang Android SDK Platform 35.
- [ ] Build APK debug.
- [ ] Uji pada perangkat Android fisik.
- [ ] Siapkan signing key untuk APK/AAB produksi.
- [ ] Uji versi rilis sebelum distribusi.

## Integrasi backend
- [ ] Tentukan penyedia AI dan model.
- [ ] Siapkan endpoint HTTPS backend.
- [ ] Simpan API key hanya di server.
- [ ] Tambahkan autentikasi, rate limit, validasi, logging, dan pembatasan biaya.
- [ ] Siapkan database dan kebijakan retensi data jika menyimpan akun/riwayat.
