# NR_PROMPT — Paket Rilis Website & Android

Paket ini menyiapkan NR_PROMPT sebagai website responsif/PWA dan proyek aplikasi Android berbasis WebView.

## Status rilis
- Source website: tersedia.
- PWA manifest dan service worker: tersedia.
- Proyek Android Studio: tersedia.
- Pemeriksaan sintaks JavaScript inline: lulus.
- Hosting/domain publik: belum dilakukan; memerlukan akun hosting dan domain milik pemilik aplikasi.
- APK biner: belum dibangun; memerlukan Android SDK/Android Studio.
- AI live/API dan akun pengguna lintas perangkat: belum dikonfigurasi. Jangan memasukkan API secret ke HTML atau APK.

## 1. Publikasikan website
Cara cepat memakai Netlify:
1. Ekstrak paket ZIP.
2. Buka folder `website`.
3. Masuk ke akun Netlify dan pilih Add new site > Deploy manually.
4. Unggah isi folder `website` (bukan folder pembungkusnya).
5. Setelah URL HTTPS diberikan, buka URL tersebut di Chrome Android.
6. Pilih menu Chrome > Install app / Tambahkan ke layar utama.

Alternatif: unggah isi folder `website` ke Vercel, Cloudflare Pages, GitHub Pages, atau hosting statis lain yang mendukung HTTPS.

## 2. Bangun APK Android
1. Instal Android Studio versi stabil dan Android SDK Platform 35.
2. Buka folder `android-app` sebagai project.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug akan muncul di `android-app/app/build/outputs/apk/debug/`.
6. Uji di perangkat Android fisik sebelum distribusi.

Project Android menggunakan Gradle Android Plugin 8.7.3 dan compileSdk 35. Paket ini tidak menyertakan Gradle Wrapper atau Android SDK.

## 3. Integrasi AI sungguhan
Saat ini generator dan template pada source dapat digunakan sebagai alat bantu berbasis antarmuka/template. Untuk jawaban dari model AI secara langsung, siapkan backend HTTPS:
- Browser/Android mengirim permintaan ke endpoint backend milik aplikasi.
- Backend menyimpan API key di environment variable/secret manager.
- Backend memvalidasi input, autentikasi, batas pemakaian, dan biaya.
- Backend memanggil penyedia model AI dan mengembalikan hasil ke aplikasi.

Jangan pernah menaruh API key privat di `index.html`, JavaScript publik, `localStorage`, atau APK.

## 4. Sebelum rilis publik
- Ganti identitas/ikon bila diperlukan dan tetapkan domain resmi.
- Tambahkan halaman kebijakan privasi dan kontak pengelola yang valid.
- Konfigurasikan backend AI dan database jika dibutuhkan.
- Uji semua tombol, form, penyimpanan, PWA offline, dan WebView Android.
- Buat signing key Android dan simpan cadangan dengan aman untuk rilis produksi.

Lihat `docs/RELEASE_CHECKLIST.md` dan `docs/AI_BACKEND_REQUIREMENTS.md`.
